G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-07-02T13:46:23+08:00*
G04 #@! TF.ProjectId,fallout-badge,66616c6c-6f75-4742-9d62-616467652e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-07-02 13:46:23*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
